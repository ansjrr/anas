import { createContext, useContext, ReactNode, useEffect, useState } from "react";
import { User, getGetMeQueryKey } from "@workspace/api-client-react";
import { useGetMe, useLogout } from "@workspace/api-client-react";

interface AuthContextType {
  user: User | null;
  setUser: (user: User | null) => void;
  isLoading: boolean;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const { data: user, isLoading: isUserLoading } = useGetMe({
    query: {
      retry: false,
      queryKey: getGetMeQueryKey(),
    },
  });
  
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  
  useEffect(() => {
    if (user && !("error" in user)) {
      setCurrentUser(user as User);
    } else {
      setCurrentUser(null);
    }
  }, [user]);

  const logoutMutation = useLogout();

  const logout = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        setCurrentUser(null);
        window.location.href = "/";
      },
    });
  };

  return (
    <AuthContext.Provider
      value={{
        user: currentUser,
        setUser: setCurrentUser,
        isLoading: isUserLoading,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
