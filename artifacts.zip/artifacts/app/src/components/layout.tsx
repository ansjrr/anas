import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { LogOut, Home, MessageSquare, Trophy, Shield, Menu, Timer, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

const LEVEL_NAMES = [
  "مبتدئ", "متعلم", "مجتهد", "متقدم", "خبير",
  "متميز", "نجم", "أسطورة", "بطل", "أسطورة المذاكرة"
];

function getLevelInfo(totalSeconds: number) {
  const totalHours = Math.floor(totalSeconds / 3600);
  const levelIndex = Math.min(Math.floor(totalHours / 6), LEVEL_NAMES.length - 1);
  const hoursInLevel = totalHours % 6;
  const progressPct = Math.round((hoursInLevel / 6) * 100);
  return { name: LEVEL_NAMES[levelIndex], level: levelIndex + 1, progressPct };
}

function getInitials(name: string) {
  return name?.slice(0, 2) ?? "؟";
}

interface SidebarProps {
  onClose?: () => void;
}

function SidebarContent({ onClose }: SidebarProps) {
  const { user, logout } = useAuth();
  const [location] = useLocation();

  const links = [
    { href: "/home", label: "الرئيسية", icon: Home },
    { href: "/chat", label: "الدردشة", icon: MessageSquare },
    { href: "/leaderboard", label: "المتصدرون", icon: Trophy },
  ];
  if (user?.isAdmin) {
    links.push({ href: "/admin", label: "لوحة المشرف", icon: Shield });
  }

  const levelInfo = getLevelInfo(user?.totalSeconds ?? 0);

  return (
    <div className="flex flex-col h-full bg-sidebar border-l border-sidebar-border w-64 text-sidebar-foreground">
      {/* Brand */}
      <div className="px-4 pt-6 pb-4 border-b border-sidebar-border">
        <div className="flex items-center gap-2 justify-center">
          <Timer size={20} className="text-primary" />
          <span className="text-xl font-bold text-primary tracking-wide">مذاكرة WorkFlow</span>
        </div>
      </div>

      {/* User Card */}
      {user && (
        <div className="px-4 py-4 border-b border-sidebar-border">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center text-primary font-bold text-sm shrink-0">
              {getInitials(user.displayName)}
            </div>
            <div className="min-w-0">
              <div className="font-semibold text-sm truncate">{user.displayName}</div>
              <div className="text-xs text-muted-foreground truncate">@{user.username}</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="bg-muted/30 rounded-lg p-2 text-center border border-border/50">
              <div className="flex items-center justify-center gap-1">
                <Zap size={12} className="text-primary" />
                <span className="text-primary font-bold text-sm">{user.points}</span>
              </div>
              <div className="text-xs text-muted-foreground">نقطة</div>
            </div>
            <div className="bg-muted/30 rounded-lg p-2 text-center border border-border/50">
              <div className="text-accent font-bold text-sm">{levelInfo.name}</div>
              <div className="text-xs text-muted-foreground">المستوى</div>
            </div>
          </div>

          {/* Level progress bar */}
          <div className="mt-2">
            <div className="flex justify-between text-xs text-muted-foreground mb-1">
              <span>التقدم نحو المستوى التالي</span>
              <span>{levelInfo.progressPct}%</span>
            </div>
            <div className="h-1.5 bg-muted/50 rounded-full overflow-hidden">
              <div
                className="h-full bg-primary rounded-full transition-all duration-500"
                style={{ width: `${levelInfo.progressPct}%` }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Nav Links */}
      <div className="flex flex-col gap-1 flex-1 px-3 py-4">
        {links.map((link) => {
          const Icon = link.icon;
          const isActive = location === link.href;
          return (
            <Link key={link.href} href={link.href} onClick={onClose}>
              <Button
                variant="ghost"
                className={`w-full justify-start gap-3 h-10 ${
                  isActive
                    ? "bg-primary/15 text-primary border border-primary/25 hover:bg-primary/20"
                    : "hover:bg-sidebar-accent/50 text-sidebar-foreground"
                }`}
              >
                <Icon size={17} className={isActive ? "text-primary" : "text-muted-foreground"} />
                <span className={isActive ? "font-semibold" : ""}>{link.label}</span>
              </Button>
            </Link>
          );
        })}
      </div>

      {/* Logout */}
      <div className="px-3 pb-4">
        <Button
          variant="ghost"
          className="w-full justify-start gap-3 h-10 text-destructive/80 hover:bg-destructive/10 hover:text-destructive border border-transparent hover:border-destructive/20"
          onClick={logout}
        >
          <LogOut size={17} />
          تسجيل الخروج
        </Button>
      </div>
    </div>
  );
}

export function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-background flex">
      {/* Desktop Sidebar */}
      <div className="hidden md:block sticky top-0 h-screen shrink-0">
        <SidebarContent />
      </div>

      {/* Mobile Header */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-40 bg-background/90 backdrop-blur border-b border-border px-4 h-14 flex items-center justify-between">
        <span className="text-lg font-bold text-primary">مذاكرة WorkFlow</span>
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="h-9 w-9 border-primary/30 text-primary">
              <Menu size={18} />
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="p-0 w-64 border-l-primary/30">
            <SidebarContent />
          </SheetContent>
        </Sheet>
      </div>

      {/* Main Content */}
      <main className="flex-1 overflow-auto md:pt-0 pt-14">
        <div className="max-w-5xl mx-auto p-4 md:p-8">
          {children}
        </div>
      </main>
    </div>
  );
}
