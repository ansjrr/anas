import { useState, useEffect, useRef, useCallback } from "react";
import { Layout } from "@/components/layout";
import { useAuth } from "@/lib/auth";
import { useSyncTimer } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Play, Square, X, MessageCircle, Clock, Zap, TrendingUp, Bell } from "lucide-react";
import { BarChart, Bar, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "wouter";

const LEVEL_NAMES = [
  "مبتدئ", "متعلم", "مجتهد", "متقدم", "خبير",
  "متميز", "نجم", "أسطورة", "بطل", "أسطورة المذاكرة"
];

function getLevelInfo(totalSeconds: number) {
  const totalHours = Math.floor(totalSeconds / 3600);
  const levelIndex = Math.min(Math.floor(totalHours / 6), LEVEL_NAMES.length - 1);
  const hoursInLevel = totalHours % 6;
  return {
    name: LEVEL_NAMES[levelIndex],
    level: levelIndex + 1,
    hoursInLevel,
    progressPct: Math.round((hoursInLevel / 6) * 100),
    hoursToNext: 6 - hoursInLevel,
  };
}

function formatTime(secs: number) {
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  const s = secs % 60;
  return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
}

function getPast7Days() {
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    days.push(d.toISOString().split("T")[0]);
  }
  return days;
}

interface LiveNotification {
  id: number;
  message: string;
  createdAt: string;
}

export default function Home() {
  const { user, setUser } = useAuth();
  const [isRunning, setIsRunning] = useState(false);
  const [sessionSeconds, setSessionSeconds] = useState(0);
  const [dailySeconds, setDailySeconds] = useState(0);
  const [totalSeconds, setTotalSeconds] = useState(0);
  const [notification, setNotification] = useState<LiveNotification | null>(null);
  const [chartData, setChartData] = useState<{ date: string; seconds: number; displayDate: string }[]>([]);

  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const sessionRef = useRef(0);
  const dailyRef = useRef(0);
  const totalRef = useRef(0);
  const userRef = useRef(user);
  const isRunningRef = useRef(false);

  const syncTimerMutation = useSyncTimer();

  // Keep refs in sync with state
  useEffect(() => { userRef.current = user; }, [user]);
  useEffect(() => { sessionRef.current = sessionSeconds; }, [sessionSeconds]);
  useEffect(() => { dailyRef.current = dailySeconds; }, [dailySeconds]);
  useEffect(() => { totalRef.current = totalSeconds; }, [totalSeconds]);

  // Load from localStorage on mount
  useEffect(() => {
    if (!user) return;
    const saved = localStorage.getItem(`wf_timer_${user.id}`);
    const today = new Date().toISOString().split("T")[0];
    if (saved) {
      const p = JSON.parse(saved);
      const baseTotal = p.totalSeconds ?? user.totalSeconds ?? 0;
      if (p.lastResetDate !== today) {
        setDailySeconds(0);
        setTotalSeconds(baseTotal);
        localStorage.setItem(`wf_timer_${user.id}`, JSON.stringify({ sessionSeconds: 0, dailySeconds: 0, totalSeconds: baseTotal, lastResetDate: today }));
      } else {
        setSessionSeconds(p.sessionSeconds ?? 0);
        setDailySeconds(p.dailySeconds ?? 0);
        setTotalSeconds(baseTotal);
      }
    } else {
      const base = user.totalSeconds ?? 0;
      setTotalSeconds(base);
      localStorage.setItem(`wf_timer_${user.id}`, JSON.stringify({ sessionSeconds: 0, dailySeconds: 0, totalSeconds: base, lastResetDate: today }));
    }
  }, [user?.id]);

  // Chart data
  useEffect(() => {
    if (!user) return;
    const today = new Date().toISOString().split("T")[0];
    const data = getPast7Days().map((date) => {
      const [, month, day] = date.split("-");
      let seconds = 0;
      if (date === today) {
        seconds = dailySeconds;
      } else {
        const h = localStorage.getItem(`wf_history_${user.id}_${date}`);
        if (h) seconds = parseInt(h, 10);
      }
      return { date, seconds, displayDate: `${day}/${month}` };
    });
    setChartData(data);
  }, [dailySeconds, user?.id]);

  // WebSocket for live admin notifications
  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    let ws: WebSocket;
    let reconnectTimeout: NodeJS.Timeout;

    function connect() {
      try {
        ws = new WebSocket(wsUrl);
        ws.onmessage = (e) => {
          try {
            const data = JSON.parse(e.data);
            if (data.type === "notification") {
              setNotification({ id: data.id, message: data.message, createdAt: data.createdAt });
            }
          } catch {}
        };
        ws.onclose = () => {
          reconnectTimeout = setTimeout(connect, 5000);
        };
      } catch {}
    }

    connect();
    return () => {
      clearTimeout(reconnectTimeout);
      if (ws) ws.close();
    };
  }, []);

  // Server sync helper (reads from refs — no stale closures)
  const syncToServer = useCallback(() => {
    const today = new Date().toISOString().split("T")[0];
    syncTimerMutation.mutate(
      { data: { dailySeconds: dailyRef.current, totalSeconds: totalRef.current, lastResetDate: today } },
      {
        onSuccess: (data) => {
          if (userRef.current) setUser({ ...userRef.current, points: data.points, totalSeconds: totalRef.current });
        },
      }
    );
  }, []);

  // Timer tick — only depends on isRunning
  useEffect(() => {
    if (!isRunning) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    timerRef.current = setInterval(() => {
      const today = new Date().toISOString().split("T")[0];
      const newSession = sessionRef.current + 1;
      const newDaily = dailyRef.current + 1;
      const newTotal = totalRef.current + 1;

      sessionRef.current = newSession;
      dailyRef.current = newDaily;
      totalRef.current = newTotal;

      setSessionSeconds(newSession);
      setDailySeconds(newDaily);
      setTotalSeconds(newTotal);

      // Persist locally
      if (userRef.current) {
        localStorage.setItem(`wf_timer_${userRef.current.id}`, JSON.stringify({ sessionSeconds: newSession, dailySeconds: newDaily, totalSeconds: newTotal, lastResetDate: today }));
        localStorage.setItem(`wf_history_${userRef.current.id}_${today}`, newDaily.toString());
      }

      // Sync every 30s
      if (newSession % 30 === 0) syncToServer();
    }, 1000);

    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [isRunning]);

  const toggleTimer = () => {
    const next = !isRunning;
    isRunningRef.current = next;
    if (!next) syncToServer();
    setIsRunning(next);
  };

  const today = new Date().toISOString().split("T")[0];
  const progress = (sessionSeconds % 3600) / 3600;
  const circumference = 2 * Math.PI * 110;
  const strokeDashoffset = circumference - progress * circumference;
  const dailyPoints = Math.floor(dailySeconds / 3600);
  const secondsToNextPoint = 3600 - (dailySeconds % 3600);
  const levelInfo = getLevelInfo(totalSeconds);

  return (
    <Layout>
      <div className="space-y-5">
        {/* Live Notification Banner */}
        <AnimatePresence>
          {notification && (
            <motion.div
              initial={{ opacity: 0, y: -16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              className="flex items-center justify-between gap-4 bg-primary/10 border border-primary/40 rounded-xl p-4 shadow-lg shadow-primary/5"
            >
              <div className="flex items-center gap-3">
                <div className="bg-primary/20 p-2 rounded-full shrink-0">
                  <Bell size={16} className="text-primary" />
                </div>
                <div>
                  <p className="text-xs text-primary font-semibold mb-0.5">رسالة من الإدارة</p>
                  <p className="text-sm">{notification.message}</p>
                </div>
              </div>
              <Button variant="ghost" size="icon" className="shrink-0 h-8 w-8 hover:bg-primary/10" onClick={() => setNotification(null)}>
                <X size={15} />
              </Button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Top Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Timer Card */}
          <Card className="col-span-1 md:col-span-2 border-border bg-card/60 backdrop-blur">
            <CardContent className="flex flex-col items-center justify-center p-8 gap-6">
              <div className="relative w-[260px] h-[260px] flex items-center justify-center">
                <svg className="w-full h-full -rotate-90" viewBox="0 0 260 260">
                  <circle cx="130" cy="130" r="110" stroke="currentColor" strokeWidth="8" fill="transparent" className="text-muted/25" />
                  <circle
                    cx="130" cy="130" r="110"
                    stroke="currentColor" strokeWidth="8" fill="transparent"
                    strokeDasharray={circumference}
                    strokeDashoffset={strokeDashoffset}
                    strokeLinecap="round"
                    className="text-primary transition-all duration-1000 ease-linear"
                  />
                </svg>
                <div className="absolute flex flex-col items-center justify-center">
                  {isRunning && (
                    <motion.div
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ repeat: Infinity, duration: 1.5 }}
                      className="w-2 h-2 rounded-full bg-green-400 mb-2"
                    />
                  )}
                  <span className="text-4xl font-mono font-bold tracking-widest tabular-nums">{formatTime(sessionSeconds)}</span>
                  <span className="text-muted-foreground text-sm mt-1">جلسة اليوم</span>
                  <span className="text-xs text-primary/70 mt-0.5">{dailyPoints} نقطة مكتسبة اليوم</span>
                </div>
              </div>

              <div className="flex flex-col items-center gap-3 w-full max-w-xs">
                <Button
                  size="lg"
                  onClick={toggleTimer}
                  className={`w-full h-14 text-lg rounded-xl font-bold transition-all duration-300 ${
                    isRunning
                      ? "bg-destructive hover:bg-destructive/90 shadow-[0_0_24px_rgba(180,20,20,0.35)]"
                      : "bg-primary hover:bg-primary/90 shadow-[0_0_24px_rgba(180,30,30,0.3)]"
                  }`}
                >
                  {isRunning ? (
                    <><Square size={18} className="ml-2" /> إيقاف المذاكرة</>
                  ) : (
                    <><Play size={18} className="ml-2" /> ابدأ المذاكرة</>
                  )}
                </Button>

                {/* Progress to next point */}
                {isRunning && (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="w-full text-center">
                    <p className="text-xs text-muted-foreground mb-1.5">
                      {Math.floor(secondsToNextPoint / 60)} دقيقة و {secondsToNextPoint % 60} ثانية حتى النقطة التالية
                    </p>
                    <div className="h-1 bg-muted/40 rounded-full overflow-hidden">
                      <motion.div
                        className="h-full bg-primary/60 rounded-full"
                        style={{ width: `${((3600 - secondsToNextPoint) / 3600) * 100}%` }}
                      />
                    </div>
                  </motion.div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Stats Column */}
          <div className="flex flex-col gap-4">
            {/* User stats */}
            <Card className="border-border bg-card/60 backdrop-blur">
              <CardHeader className="pb-2 pt-4 px-4">
                <CardTitle className="text-base">مرحباً، {user?.displayName} 👋</CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-4 space-y-3">
                <StatRow icon={<Zap size={15} className="text-primary" />} label="النقاط" value={`${user?.points ?? 0} نقطة`} highlight />
                <StatRow icon={<TrendingUp size={15} className="text-accent" />} label="المستوى" value={levelInfo.name} />
                <StatRow icon={<Clock size={15} className="text-muted-foreground" />} label="الإجمالي" value={`${Math.floor(totalSeconds / 3600)} ساعة`} />
              </CardContent>
            </Card>

            {/* Level progress */}
            <Card className="border-border bg-card/60 backdrop-blur">
              <CardContent className="p-4 space-y-2">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-muted-foreground">المستوى {levelInfo.level}</span>
                  <span className="text-primary font-semibold">{levelInfo.name}</span>
                </div>
                <div className="h-2 bg-muted/40 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-primary to-accent rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: `${levelInfo.progressPct}%` }}
                    transition={{ duration: 1, ease: "easeOut" }}
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  {levelInfo.hoursInLevel} / 6 ساعات — {levelInfo.hoursToNext > 0 ? `${levelInfo.hoursToNext} ساعات للمستوى التالي` : "وصلت للحد الأقصى 🎉"}
                </p>
              </CardContent>
            </Card>

            {/* Chat shortcut */}
            <Link href="/chat">
              <Button className="w-full h-12 bg-secondary hover:bg-secondary/80 border border-primary/20 text-foreground">
                <MessageCircle size={17} className="ml-2 text-primary" />
                دخول الدردشة العامة
              </Button>
            </Link>
          </div>
        </div>

        {/* Weekly Chart */}
        <Card className="border-border bg-card/60 backdrop-blur">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">التقدم الأسبوعي (بالدقائق)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-52 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 5, right: 5, left: -25, bottom: 0 }}>
                  <XAxis dataKey="displayDate" stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={false} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} tickLine={false} axisLine={false} tickFormatter={(v) => `${Math.floor(v / 60)}`} />
                  <Tooltip
                    cursor={{ fill: "hsl(var(--muted)/0.15)" }}
                    contentStyle={{ backgroundColor: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px", fontSize: "12px" }}
                    formatter={(value: number) => [`${Math.floor(value / 60)} دقيقة`, "الوقت"]}
                    labelStyle={{ color: "hsl(var(--primary))", fontWeight: "bold" }}
                  />
                  <Bar dataKey="seconds" radius={[4, 4, 0, 0]} maxBarSize={40}>
                    {chartData.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={entry.date === today ? "hsl(var(--primary))" : "hsl(var(--muted-foreground)/0.4)"}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}

function StatRow({ icon, label, value, highlight }: { icon: React.ReactNode; label: string; value: string; highlight?: boolean }) {
  return (
    <div className="flex items-center justify-between p-3 bg-muted/20 rounded-lg border border-border/50">
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        {icon}
        {label}
      </div>
      <span className={`font-bold text-sm ${highlight ? "text-primary" : ""}`}>{value}</span>
    </div>
  );
}
