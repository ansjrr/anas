import { useState } from "react";
import { Layout } from "@/components/layout";
import { useAdminGetUsers, useAdminUpdateUser, useAdminDeleteUser, useAdminBroadcast } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Trash2, Save, Send, Users, Star, Clock, Shield, X } from "lucide-react";

export default function Admin() {
  const { data: users, isLoading } = useAdminGetUsers();
  const updateMutation = useAdminUpdateUser();
  const deleteMutation = useAdminDeleteUser();
  const broadcastMutation = useAdminBroadcast();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [broadcastMessage, setBroadcastMessage] = useState("");
  const [editingUser, setEditingUser] = useState<number | null>(null);
  const [editData, setEditData] = useState({ points: 0, totalSeconds: 0, displayName: "" });
  const [confirmDelete, setConfirmDelete] = useState<number | null>(null);

  const handleEdit = (user: NonNullable<typeof users>[number]) => {
    setEditingUser(user.id);
    setEditData({ points: user.points, totalSeconds: user.totalSeconds, displayName: user.displayName });
  };

  const handleSave = (id: number) => {
    updateMutation.mutate({ id, data: editData }, {
      onSuccess: () => {
        setEditingUser(null);
        queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
        toast({ title: "✅ تم التحديث بنجاح" });
      },
      onError: () => toast({ variant: "destructive", title: "حدث خطأ أثناء التحديث" }),
    });
  };

  const handleDelete = (id: number) => {
    deleteMutation.mutate({ id }, {
      onSuccess: () => {
        setConfirmDelete(null);
        queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
        toast({ title: "🗑️ تم الحذف بنجاح" });
      },
      onError: () => toast({ variant: "destructive", title: "حدث خطأ أثناء الحذف" }),
    });
  };

  const handleBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastMessage.trim()) return;
    broadcastMutation.mutate({ data: { message: broadcastMessage } }, {
      onSuccess: () => {
        setBroadcastMessage("");
        toast({ title: "📢 تم إرسال الإشعار لجميع المستخدمين" });
      },
      onError: () => toast({ variant: "destructive", title: "فشل إرسال الإشعار" }),
    });
  };

  const totalUsers = users?.length ?? 0;
  const totalPoints = users?.reduce((s, u) => s + u.points, 0) ?? 0;
  const totalHours = Math.floor((users?.reduce((s, u) => s + u.totalSeconds, 0) ?? 0) / 3600);
  const adminCount = users?.filter((u) => u.isAdmin).length ?? 0;

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="bg-primary/15 p-2.5 rounded-xl border border-primary/25">
            <Shield size={20} className="text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-primary">لوحة المشرف</h1>
            <p className="text-sm text-muted-foreground">إدارة المستخدمين والإشعارات</p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <StatCard icon={<Users size={16} className="text-blue-400" />} label="المستخدمون" value={totalUsers} color="blue" />
          <StatCard icon={<Star size={16} className="text-primary" />} label="إجمالي النقاط" value={totalPoints} color="red" />
          <StatCard icon={<Clock size={16} className="text-accent" />} label="إجمالي الساعات" value={totalHours} color="gold" />
          <StatCard icon={<Shield size={16} className="text-green-400" />} label="المشرفون" value={adminCount} color="green" />
        </div>

        <Tabs defaultValue="users" className="w-full">
          <TabsList className="bg-muted/30 border border-border h-10">
            <TabsTrigger value="users" className="data-[state=active]:bg-primary/15 data-[state=active]:text-primary">
              المستخدمون ({totalUsers})
            </TabsTrigger>
            <TabsTrigger value="broadcast" className="data-[state=active]:bg-primary/15 data-[state=active]:text-primary">
              إرسال إشعار
            </TabsTrigger>
          </TabsList>

          {/* Users Tab */}
          <TabsContent value="users">
            <Card className="border-border bg-card/60 backdrop-blur overflow-hidden">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-muted/20 hover:bg-muted/20">
                        <TableHead className="font-semibold">الاسم الظاهر</TableHead>
                        <TableHead className="font-semibold">المستخدم</TableHead>
                        <TableHead className="font-semibold">النقاط</TableHead>
                        <TableHead className="font-semibold">الساعات</TableHead>
                        <TableHead className="font-semibold">الصلاحية</TableHead>
                        <TableHead className="font-semibold">إجراءات</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {isLoading ? (
                        [...Array(3)].map((_, i) => (
                          <TableRow key={i}>
                            <TableCell colSpan={6}><div className="h-4 bg-muted/30 rounded animate-pulse" /></TableCell>
                          </TableRow>
                        ))
                      ) : users?.map((u) => (
                        <TableRow key={u.id} className={`${editingUser === u.id ? "bg-primary/5" : "hover:bg-muted/10"} transition-colors`}>
                          <TableCell>
                            {editingUser === u.id ? (
                              <Input value={editData.displayName} onChange={(e) => setEditData({ ...editData, displayName: e.target.value })} className="h-8 w-36 text-sm" />
                            ) : (
                              <span className="font-medium">{u.displayName}</span>
                            )}
                          </TableCell>
                          <TableCell className="text-muted-foreground text-sm">@{u.username}</TableCell>
                          <TableCell>
                            {editingUser === u.id ? (
                              <Input type="number" value={editData.points} onChange={(e) => setEditData({ ...editData, points: Number(e.target.value) })} className="h-8 w-20 text-sm" />
                            ) : (
                              <span className="text-primary font-semibold">{u.points}</span>
                            )}
                          </TableCell>
                          <TableCell>
                            {editingUser === u.id ? (
                              <Input type="number" value={Math.floor(editData.totalSeconds / 3600)} onChange={(e) => setEditData({ ...editData, totalSeconds: Number(e.target.value) * 3600 })} className="h-8 w-20 text-sm" />
                            ) : (
                              <span className="text-muted-foreground text-sm">{Math.floor(u.totalSeconds / 3600)} ساعة</span>
                            )}
                          </TableCell>
                          <TableCell>
                            {u.isAdmin ? (
                              <Badge className="bg-primary/15 text-primary border border-primary/25 text-xs">مشرف</Badge>
                            ) : (
                              <Badge variant="outline" className="text-xs text-muted-foreground">عادي</Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            {editingUser === u.id ? (
                              <div className="flex gap-1.5">
                                <Button size="sm" onClick={() => handleSave(u.id)} disabled={updateMutation.isPending} className="h-7 bg-green-600 hover:bg-green-700 text-xs px-2">
                                  <Save size={12} className="ml-1" /> حفظ
                                </Button>
                                <Button size="sm" variant="ghost" onClick={() => setEditingUser(null)} className="h-7 text-xs px-2">
                                  <X size={12} />
                                </Button>
                              </div>
                            ) : (
                              <div className="flex gap-1.5">
                                <Button size="sm" variant="outline" onClick={() => handleEdit(u)} className="h-7 text-xs px-2.5 border-border hover:border-primary/40">
                                  تعديل
                                </Button>
                                {confirmDelete === u.id ? (
                                  <div className="flex gap-1">
                                    <Button size="sm" variant="destructive" onClick={() => handleDelete(u.id)} className="h-7 text-xs px-2">تأكيد</Button>
                                    <Button size="sm" variant="ghost" onClick={() => setConfirmDelete(null)} className="h-7 text-xs px-1"><X size={12} /></Button>
                                  </div>
                                ) : (
                                  <Button size="sm" variant="ghost" onClick={() => setConfirmDelete(u.id)} className="h-7 w-7 p-0 text-destructive/60 hover:text-destructive hover:bg-destructive/10">
                                    <Trash2 size={13} />
                                  </Button>
                                )}
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Broadcast Tab */}
          <TabsContent value="broadcast">
            <Card className="border-border bg-card/60 backdrop-blur max-w-2xl">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Send size={16} className="text-primary" />
                  إرسال إشعار عام
                </CardTitle>
                <p className="text-sm text-muted-foreground">سيصل الإشعار فوراً لجميع المستخدمين المتصلين</p>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleBroadcast} className="space-y-3">
                  <Input
                    value={broadcastMessage}
                    onChange={(e) => setBroadcastMessage(e.target.value)}
                    placeholder="اكتب رسالتك التحفيزية أو الإعلان هنا..."
                    className="bg-background/60 border-border focus:border-primary h-11"
                    maxLength={300}
                  />
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">{broadcastMessage.length}/300</span>
                    <Button
                      type="submit"
                      disabled={!broadcastMessage.trim() || broadcastMutation.isPending}
                      className="bg-primary hover:bg-primary/90 px-6"
                    >
                      <Send size={15} className="ml-2 rtl:rotate-180" />
                      {broadcastMutation.isPending ? "جاري الإرسال..." : "إرسال للجميع"}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}

function StatCard({ icon, label, value, color }: { icon: React.ReactNode; label: string; value: number; color: string }) {
  const colorMap: Record<string, string> = {
    blue: "bg-blue-500/8 border-blue-500/20",
    red: "bg-primary/8 border-primary/20",
    gold: "bg-accent/8 border-accent/20",
    green: "bg-green-500/8 border-green-500/20",
  };
  return (
    <Card className={`border ${colorMap[color] ?? "border-border bg-card/50"}`}>
      <CardContent className="p-4 flex items-center gap-3">
        <div className="bg-muted/30 p-2 rounded-lg">{icon}</div>
        <div>
          <div className="text-xl font-bold">{value}</div>
          <div className="text-xs text-muted-foreground">{label}</div>
        </div>
      </CardContent>
    </Card>
  );
}
