import { Layout } from "@/components/layout";
import { useAuth } from "@/lib/auth";
import { useGetLeaderboard } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Trophy, Medal, Star, Crown } from "lucide-react";
import { motion } from "framer-motion";

const LEVEL_NAMES = [
  "مبتدئ", "متعلم", "مجتهد", "متقدم", "خبير",
  "متميز", "نجم", "أسطورة", "بطل", "أسطورة المذاكرة"
];

function getLevelName(totalSeconds: number) {
  const level = Math.min(Math.floor(Math.floor(totalSeconds / 3600) / 6), LEVEL_NAMES.length - 1);
  return LEVEL_NAMES[level];
}

function getInitials(name: string) {
  return name?.slice(0, 2) ?? "؟";
}

interface RankBadgeProps {
  index: number;
}

function RankBadge({ index }: RankBadgeProps) {
  if (index === 0) return <Crown size={22} className="text-yellow-400 drop-shadow-[0_0_6px_rgba(250,204,21,0.6)]" />;
  if (index === 1) return <Trophy size={20} className="text-slate-300 drop-shadow-[0_0_4px_rgba(203,213,225,0.5)]" />;
  if (index === 2) return <Medal size={20} className="text-amber-500 drop-shadow-[0_0_4px_rgba(245,158,11,0.5)]" />;
  return <span className="text-muted-foreground/60 font-mono font-bold text-sm w-5 text-center">#{index + 1}</span>;
}

const TOP3_STYLES = [
  { card: "border-yellow-400/40 bg-gradient-to-l from-yellow-400/8 to-transparent", avatar: "border-yellow-400/60 bg-yellow-400/15 text-yellow-300" },
  { card: "border-slate-400/40 bg-gradient-to-l from-slate-400/8 to-transparent", avatar: "border-slate-400/60 bg-slate-400/15 text-slate-300" },
  { card: "border-amber-600/40 bg-gradient-to-l from-amber-600/8 to-transparent", avatar: "border-amber-600/60 bg-amber-600/15 text-amber-400" },
];

export default function Leaderboard() {
  const { user } = useAuth();
  const { data: leaderboard, isLoading } = useGetLeaderboard();

  const myRank = leaderboard?.findIndex((e) => e.id === user?.id) ?? -1;

  return (
    <Layout>
      <div className="max-w-2xl mx-auto space-y-5">
        {/* Header */}
        <div className="text-center py-4">
          <div className="flex items-center justify-center gap-3 mb-2">
            <Trophy size={28} className="text-primary" />
            <h1 className="text-3xl font-bold text-primary">لوحة الشرف</h1>
          </div>
          <p className="text-muted-foreground text-sm">أفضل 20 طالباً التزاماً بالمذاكرة</p>
          {myRank >= 0 && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="inline-flex items-center gap-2 mt-3 px-4 py-1.5 bg-primary/10 border border-primary/30 rounded-full text-sm"
            >
              <Star size={14} className="text-primary" />
              <span>ترتيبك الحالي: <strong className="text-primary">#{myRank + 1}</strong></span>
            </motion.div>
          )}
        </div>

        {/* List */}
        {isLoading ? (
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-16 bg-muted/20 rounded-xl animate-pulse border border-border/30" />
            ))}
          </div>
        ) : (
          <div className="space-y-2">
            {leaderboard?.map((entry, index) => {
              const isMe = entry.id === user?.id;
              const style = index < 3 ? TOP3_STYLES[index] : null;

              return (
                <motion.div
                  key={entry.id}
                  initial={{ opacity: 0, x: -16 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.04, duration: 0.3 }}
                >
                  <Card className={`border transition-all ${
                    isMe
                      ? "border-primary/50 bg-primary/8 shadow-[0_0_16px_rgba(180,30,30,0.15)]"
                      : style
                      ? style.card
                      : "border-border bg-card/50"
                  }`}>
                    <CardContent className="p-3 flex items-center gap-3">
                      {/* Rank */}
                      <div className="w-7 flex items-center justify-center shrink-0">
                        <RankBadge index={index} />
                      </div>

                      {/* Avatar */}
                      <div className={`w-9 h-9 rounded-full border flex items-center justify-center text-xs font-bold shrink-0 ${
                        style ? style.avatar : isMe ? "border-primary/50 bg-primary/20 text-primary" : "border-border bg-muted/30 text-muted-foreground"
                      }`}>
                        {getInitials(entry.displayName)}
                      </div>

                      {/* Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className={`font-semibold text-sm truncate ${isMe ? "text-primary" : ""}`}>
                            {entry.displayName}
                          </span>
                          {isMe && (
                            <span className="text-xs bg-primary/15 text-primary border border-primary/20 px-1.5 py-0.5 rounded-full shrink-0">أنت</span>
                          )}
                        </div>
                        <div className="text-xs text-muted-foreground/70 flex items-center gap-2">
                          <span>{getLevelName(entry.totalSeconds)}</span>
                          <span className="opacity-40">·</span>
                          <span>{Math.floor(entry.totalSeconds / 3600)} ساعة</span>
                        </div>
                      </div>

                      {/* Points */}
                      <div className={`text-left shrink-0 px-3 py-1.5 rounded-lg font-bold text-sm ${
                        index === 0 ? "bg-yellow-400/15 text-yellow-400 border border-yellow-400/25" :
                        index === 1 ? "bg-slate-400/15 text-slate-300 border border-slate-400/25" :
                        index === 2 ? "bg-amber-500/15 text-amber-400 border border-amber-500/25" :
                        isMe ? "bg-primary/15 text-primary border border-primary/25" :
                        "bg-muted/30 text-muted-foreground border border-border/30"
                      }`}>
                        {entry.points} <span className="font-normal text-xs opacity-70">نقطة</span>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        )}

        {!isLoading && (!leaderboard || leaderboard.length === 0) && (
          <div className="text-center py-16 text-muted-foreground">
            <Trophy size={40} className="mx-auto mb-3 opacity-20" />
            <p>لا يوجد مستخدمون بعد. كن الأول!</p>
          </div>
        )}
      </div>
    </Layout>
  );
}
