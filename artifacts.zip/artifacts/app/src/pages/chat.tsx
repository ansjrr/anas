import { useState, useEffect, useRef } from "react";
import { Layout } from "@/components/layout";
import { useAuth } from "@/lib/auth";
import { useGetChatMessages, useSendChatMessage } from "@workspace/api-client-react";
import { ChatMessage } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, Wifi, WifiOff } from "lucide-react";
import { format } from "date-fns";
import { motion } from "framer-motion";

function getInitials(name: string) {
  return name?.slice(0, 2) ?? "؟";
}

const USER_COLORS = [
  "bg-primary/20 text-primary border-primary/30",
  "bg-accent/20 text-accent border-accent/30",
  "bg-blue-500/20 text-blue-400 border-blue-400/30",
  "bg-green-500/20 text-green-400 border-green-400/30",
  "bg-purple-500/20 text-purple-400 border-purple-400/30",
];

function getUserColor(userId: number) {
  return USER_COLORS[userId % USER_COLORS.length];
}

export default function Chat() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [isConnected, setIsConnected] = useState(false);
  const [onlineCount, setOnlineCount] = useState(1);
  const scrollRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectRef = useRef<NodeJS.Timeout | null>(null);

  const { data: initialMessages } = useGetChatMessages({ limit: 80 });
  const sendMutation = useSendChatMessage();

  useEffect(() => {
    if (initialMessages) {
      setMessages(initialMessages.slice().reverse());
    }
  }, [initialMessages]);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // WebSocket with auto-reconnect
  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    function connect() {
      try {
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = () => setIsConnected(true);

        ws.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);
            if (data.type === "new_message") {
              setMessages((prev) => {
                // Avoid duplicates
                if (prev.some((m) => m.id === data.id)) return prev;
                return [...prev, data as ChatMessage];
              });
            }
          } catch {}
        };

        ws.onclose = () => {
          setIsConnected(false);
          wsRef.current = null;
          reconnectRef.current = setTimeout(connect, 4000);
        };

        ws.onerror = () => {
          ws.close();
        };
      } catch {}
    }

    connect();
    return () => {
      if (reconnectRef.current) clearTimeout(reconnectRef.current);
      if (wsRef.current) wsRef.current.close();
    };
  }, []);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim()) return;
    const text = newMessage.trim();
    setNewMessage("");
    sendMutation.mutate({ data: { message: text } });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend(e as unknown as React.FormEvent);
    }
  };

  return (
    <Layout>
      <Card className="h-[calc(100vh-8rem)] md:h-[calc(100vh-5rem)] flex flex-col border-border bg-card/60 backdrop-blur overflow-hidden">
        {/* Header */}
        <div className="px-5 py-3 border-b border-border bg-muted/10 flex items-center justify-between shrink-0">
          <div>
            <h2 className="text-lg font-bold text-primary">الدردشة العامة</h2>
            <p className="text-xs text-muted-foreground">تحدث مع زملائك وشارك تقدمك</p>
          </div>
          <div className={`flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full border ${isConnected ? "border-green-500/30 text-green-400 bg-green-500/10" : "border-muted/30 text-muted-foreground bg-muted/10"}`}>
            {isConnected ? <Wifi size={12} /> : <WifiOff size={12} />}
            {isConnected ? "متصل" : "جاري الاتصال..."}
          </div>
        </div>

        {/* Messages */}
        <ScrollArea className="flex-1 px-4 py-3" ref={scrollRef}>
          <div className="space-y-4 min-h-full">
            {messages.length === 0 && (
              <div className="flex flex-col items-center justify-center h-40 text-muted-foreground text-sm gap-2">
                <span className="text-3xl">💬</span>
                <span>لا توجد رسائل بعد. كن أول من يتحدث!</span>
              </div>
            )}

            {messages.map((msg, idx) => {
              const isMe = msg.userId === user?.id;
              const showAvatar = idx === 0 || messages[idx - 1].userId !== msg.userId;

              return (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.2 }}
                  className={`flex gap-2 ${isMe ? "flex-row-reverse" : "flex-row"}`}
                >
                  {/* Avatar */}
                  <div className="w-8 shrink-0 mt-1">
                    {showAvatar && !isMe && (
                      <div className={`w-8 h-8 rounded-full border flex items-center justify-center text-xs font-bold ${getUserColor(msg.userId)}`}>
                        {getInitials(msg.displayName)}
                      </div>
                    )}
                  </div>

                  <div className={`flex flex-col max-w-[75%] ${isMe ? "items-end" : "items-start"}`}>
                    {showAvatar && (
                      <div className={`flex items-baseline gap-2 mb-1 ${isMe ? "flex-row-reverse" : "flex-row"}`}>
                        <span className={`text-xs font-semibold ${isMe ? "text-primary" : "text-foreground/80"}`}>
                          {isMe ? "أنت" : msg.displayName}
                        </span>
                        <span className="text-xs text-muted-foreground/60">
                          {format(new Date(msg.createdAt), "HH:mm")}
                        </span>
                      </div>
                    )}
                    <div className={`px-3.5 py-2 rounded-xl text-sm break-words leading-relaxed ${
                      isMe
                        ? "bg-primary text-primary-foreground rounded-tl-sm"
                        : "bg-muted/50 text-foreground border border-border/50 rounded-tr-sm"
                    }`}>
                      {msg.message}
                    </div>
                  </div>
                </motion.div>
              );
            })}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        {/* Input */}
        <div className="px-4 py-3 border-t border-border bg-muted/10 shrink-0">
          <form onSubmit={handleSend} className="flex gap-2 items-center">
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="اكتب رسالتك... (Enter للإرسال)"
              className="flex-1 bg-background/50 border-border/60 focus:border-primary h-10 text-sm"
              maxLength={500}
            />
            <Button
              type="submit"
              size="icon"
              disabled={!newMessage.trim() || sendMutation.isPending}
              className="h-10 w-10 bg-primary hover:bg-primary/90 shrink-0"
            >
              <Send size={15} className="rtl:rotate-180" />
            </Button>
          </form>
        </div>
      </Card>
    </Layout>
  );
}
