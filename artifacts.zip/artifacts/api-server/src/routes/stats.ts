import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { desc, sql } from "drizzle-orm";

const router = Router();

router.get("/stats/leaderboard", async (req, res): Promise<void> => {
  const users = await db
    .select({
      id: usersTable.id,
      username: usersTable.username,
      displayName: usersTable.displayName,
      points: usersTable.points,
      totalSeconds: usersTable.totalSeconds,
    })
    .from(usersTable)
    .orderBy(desc(usersTable.points))
    .limit(20);

  res.json(users);
});

router.get("/stats/summary", async (req, res): Promise<void> => {
  const [totals] = await db
    .select({
      totalUsers: sql<number>`count(*)::int`,
      totalStudyHours: sql<number>`coalesce(sum(${usersTable.totalSeconds}), 0) / 3600.0`,
      activeToday: sql<number>`count(case when ${usersTable.dailySeconds} > 0 then 1 end)::int`,
    })
    .from(usersTable);

  const [top] = await db
    .select({ displayName: usersTable.displayName })
    .from(usersTable)
    .orderBy(desc(usersTable.points))
    .limit(1);

  res.json({
    totalUsers: totals?.totalUsers ?? 0,
    totalStudyHours: Number((totals?.totalStudyHours ?? 0).toFixed(1)),
    activeToday: totals?.activeToday ?? 0,
    topStudier: top?.displayName ?? null,
  });
});

export default router;
