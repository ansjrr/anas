import { Router } from "express";
import { db, chatMessagesTable, usersTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";
import { SendChatMessageBody, GetChatMessagesQueryParams } from "@workspace/api-zod";
import { broadcast } from "../lib/ws";

const router = Router();

async function formatMessage(msg: typeof chatMessagesTable.$inferSelect & { user?: typeof usersTable.$inferSelect }) {
  return {
    id: msg.id,
    userId: msg.userId,
    username: msg.user?.username ?? "",
    displayName: msg.user?.displayName ?? "",
    message: msg.message,
    createdAt: msg.createdAt.toISOString(),
  };
}

router.get("/chat/messages", async (req, res): Promise<void> => {
  const params = GetChatMessagesQueryParams.safeParse(req.query);
  const limit = params.success ? (params.data.limit ?? 50) : 50;

  const messages = await db
    .select({
      id: chatMessagesTable.id,
      userId: chatMessagesTable.userId,
      message: chatMessagesTable.message,
      createdAt: chatMessagesTable.createdAt,
      username: usersTable.username,
      displayName: usersTable.displayName,
    })
    .from(chatMessagesTable)
    .leftJoin(usersTable, eq(chatMessagesTable.userId, usersTable.id))
    .orderBy(desc(chatMessagesTable.createdAt))
    .limit(limit);

  const formatted = messages.map((m) => ({
    id: m.id,
    userId: m.userId,
    username: m.username ?? "",
    displayName: m.displayName ?? "",
    message: m.message,
    createdAt: m.createdAt.toISOString(),
  }));

  res.json(formatted.reverse());
});

router.post("/chat/messages", requireAuth, async (req, res): Promise<void> => {
  const parsed = SendChatMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const user = (req as any).user as typeof usersTable.$inferSelect;

  const [msg] = await db
    .insert(chatMessagesTable)
    .values({ userId: user.id, message: parsed.data.message })
    .returning();

  const formatted = {
    id: msg.id,
    userId: msg.userId,
    username: user.username,
    displayName: user.displayName,
    message: msg.message,
    createdAt: msg.createdAt.toISOString(),
  };

  broadcast({ type: "new_message", ...formatted });

  res.status(201).json(formatted);
});

export default router;
