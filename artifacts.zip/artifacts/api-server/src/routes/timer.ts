import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";
import { SyncTimerBody } from "@workspace/api-zod";

const router = Router();

function todayKey(): string {
  return new Date().toISOString().split("T")[0];
}

router.post("/timer/sync", requireAuth, async (req, res): Promise<void> => {
  const parsed = SyncTimerBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const user = (req as any).user as typeof usersTable.$inferSelect;
  let { dailySeconds, totalSeconds, lastResetDate } = parsed.data;

  const today = todayKey();

  // Auto-reset if the user's last reset date is before today
  const storedResetDate = user.lastResetDate;
  if (storedResetDate && storedResetDate !== today && (!lastResetDate || lastResetDate !== today)) {
    dailySeconds = 0;
    lastResetDate = today;
  }

  // Points: 1 point per hour of daily study (floor)
  const earnedPoints = Math.floor(dailySeconds / 3600);

  const [updated] = await db
    .update(usersTable)
    .set({
      totalSeconds,
      dailySeconds,
      lastResetDate: lastResetDate ?? today,
      points: earnedPoints,
    })
    .where(eq(usersTable.id, user.id))
    .returning();

  res.json({
    points: updated.points,
    totalSeconds: updated.totalSeconds,
    dailySeconds: updated.dailySeconds,
    lastResetDate: updated.lastResetDate ?? null,
  });
});

export default router;
