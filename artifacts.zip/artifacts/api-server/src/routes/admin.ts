import { Router } from "express";
import { db, usersTable, notificationsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { requireAdmin } from "../middlewares/auth";
import {
  AdminUpdateUserBody,
  AdminUpdateUserParams,
  AdminDeleteUserParams,
  AdminBroadcastBody,
} from "@workspace/api-zod";
import { broadcast } from "../lib/ws";

const router = Router();

function formatUser(user: typeof usersTable.$inferSelect) {
  return {
    id: user.id,
    username: user.username,
    displayName: user.displayName,
    points: user.points,
    totalSeconds: user.totalSeconds,
    dailySeconds: user.dailySeconds,
    isAdmin: user.isAdmin,
    createdAt: user.createdAt.toISOString(),
  };
}

router.get("/admin/users", requireAdmin, async (req, res): Promise<void> => {
  const users = await db.select().from(usersTable).orderBy(desc(usersTable.points));
  res.json(users.map(formatUser));
});

router.patch("/admin/users/:id", requireAdmin, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = AdminUpdateUserParams.safeParse({ id: parseInt(rawId, 10) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = AdminUpdateUserBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const updateData: Partial<typeof usersTable.$inferInsert> = {};
  if (body.data.points !== undefined) updateData.points = body.data.points;
  if (body.data.totalSeconds !== undefined) updateData.totalSeconds = body.data.totalSeconds;
  if (body.data.displayName !== undefined) updateData.displayName = body.data.displayName;

  const [updated] = await db
    .update(usersTable)
    .set(updateData)
    .where(eq(usersTable.id, params.data.id))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  res.json(formatUser(updated));
});

router.delete("/admin/users/:id", requireAdmin, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = AdminDeleteUserParams.safeParse({ id: parseInt(rawId, 10) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  await db.delete(usersTable).where(eq(usersTable.id, params.data.id));
  res.json({ success: true });
});

router.post("/admin/broadcast", requireAdmin, async (req, res): Promise<void> => {
  const parsed = AdminBroadcastBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [notification] = await db
    .insert(notificationsTable)
    .values({ message: parsed.data.message })
    .returning();

  broadcast({
    type: "notification",
    id: notification.id,
    message: notification.message,
    createdAt: notification.createdAt.toISOString(),
  });

  res.json({ success: true });
});

router.get("/admin/notifications", async (req, res): Promise<void> => {
  const notifications = await db
    .select()
    .from(notificationsTable)
    .orderBy(desc(notificationsTable.createdAt))
    .limit(10);

  res.json(
    notifications.map((n) => ({
      id: n.id,
      message: n.message,
      createdAt: n.createdAt.toISOString(),
    })),
  );
});

export default router;
