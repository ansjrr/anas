import { useState } from "react";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ShieldCheck, Users, ShoppingBag, ScrollText, Trash2, Plus, Edit, Loader2, Backpack } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const H = { Authorization: "Bearer aNaS12" };
const J = { ...H, "Content-Type": "application/json" };

const fetchUsers = () => fetch("/api/workflow/admin/users", { headers: H }).then(r => r.json());
const fetchShop = () => fetch("/api/workflow/admin/shop", { headers: H }).then(r => r.json());
const fetchLogs = () => fetch("/api/workflow/admin/logs", { headers: H }).then(r => r.json());
const fetchInventory = () => fetch("/api/workflow/admin/inventory", { headers: H }).then(r => r.json());

export default function Admin() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [newItemName, setNewItemName] = useState("");
  const [newItemPrice, setNewItemPrice] = useState("");
  const [newItemEmoji, setNewItemEmoji] = useState("");
  const [newItemDesc, setNewItemDesc] = useState("");
  const [newItemEffectType, setNewItemEffectType] = useState("title");
  const [newItemEffectVal, setNewItemEffectVal] = useState("");
  const [isAddShopOpen, setIsAddShopOpen] = useState(false);

  const [adjustUserId, setAdjustUserId] = useState<string | null>(null);
  const [adjustPoints, setAdjustPoints] = useState("");
  const [adjustSeconds, setAdjustSeconds] = useState("");

  if (!user || user.username !== "admin") {
    setLocation("/");
    return null;
  }

  const { data: usersData, isLoading: loadingUsers } = useQuery({ queryKey: ["admin_users"], queryFn: fetchUsers });
  const { data: shopData, isLoading: loadingShop } = useQuery({ queryKey: ["admin_shop"], queryFn: fetchShop });
  const { data: logsData, isLoading: loadingLogs } = useQuery({ queryKey: ["admin_logs"], queryFn: fetchLogs });
  const { data: inventoryData, isLoading: loadingInventory } = useQuery({ queryKey: ["admin_inventory"], queryFn: fetchInventory });

  const addShopItemMut = useMutation({
    mutationFn: (data: object) => fetch("/api/workflow/admin/shop", { method: "POST", headers: J, body: JSON.stringify(data) }).then(r => r.json()),
    onSuccess: (res) => {
      if (res.success) {
        toast({ title: "تم الإضافة", description: "تم إضافة العنصر بنجاح" });
        setIsAddShopOpen(false);
        setNewItemName(""); setNewItemPrice(""); setNewItemEmoji(""); setNewItemDesc(""); setNewItemEffectVal("");
        queryClient.invalidateQueries({ queryKey: ["admin_shop"] });
      } else {
        toast({ variant: "destructive", title: "خطأ", description: res.error });
      }
    },
  });

  const deleteShopItemMut = useMutation({
    mutationFn: (id: number) => fetch(`/api/workflow/admin/shop/${id}`, { method: "DELETE", headers: H }).then(r => r.json()),
    onSuccess: () => {
      toast({ title: "تم الحذف" });
      queryClient.invalidateQueries({ queryKey: ["admin_shop"] });
    },
  });

  const adjustUserMut = useMutation({
    mutationFn: ({ id, points, totalSeconds }: { id: string; points: number; totalSeconds: number }) =>
      fetch(`/api/workflow/admin/users/${id}/adjust`, { method: "POST", headers: J, body: JSON.stringify({ points, totalSeconds }) }).then(r => r.json()),
    onSuccess: () => {
      toast({ title: "تم التعديل" });
      setAdjustUserId(null);
      queryClient.invalidateQueries({ queryKey: ["admin_users"] });
    },
  });

  const deleteUserMut = useMutation({
    mutationFn: (id: string) => fetch(`/api/workflow/admin/users/${id}`, { method: "DELETE", headers: H }).then(r => r.json()),
    onSuccess: () => {
      toast({ title: "تم الحذف" });
      queryClient.invalidateQueries({ queryKey: ["admin_users"] });
    },
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center gap-3 mb-6">
        <ShieldCheck className="w-9 h-9 text-primary" />
        <div>
          <h1 className="text-2xl font-bold">لوحة المشرف</h1>
          <p className="text-muted-foreground text-sm">إدارة النظام والمستخدمين</p>
        </div>
      </div>

      <Tabs defaultValue="users" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="users" className="gap-1.5 text-xs sm:text-sm">
            <Users className="w-4 h-4" /> المستخدمين
          </TabsTrigger>
          <TabsTrigger value="inventory" className="gap-1.5 text-xs sm:text-sm">
            <Backpack className="w-4 h-4" /> الحقائب
          </TabsTrigger>
          <TabsTrigger value="shop" className="gap-1.5 text-xs sm:text-sm">
            <ShoppingBag className="w-4 h-4" /> المتجر
          </TabsTrigger>
          <TabsTrigger value="logs" className="gap-1.5 text-xs sm:text-sm">
            <ScrollText className="w-4 h-4" /> السجلات
          </TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="mt-6">
          <Card className="border-primary/20 bg-card/50">
            <CardHeader>
              <CardTitle>إدارة المستخدمين</CardTitle>
              <CardDescription>عرض وتعديل وحذف مستخدمي النظام</CardDescription>
            </CardHeader>
            <CardContent>
              {loadingUsers ? (
                <div className="flex justify-center p-8"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-right">
                    <thead>
                      <tr className="border-b border-border/50 text-muted-foreground text-sm">
                        <th className="p-3">المستخدم</th>
                        <th className="p-3">النقاط</th>
                        <th className="p-3">الساعات</th>
                        <th className="p-3">تاريخ التسجيل</th>
                        <th className="p-3">إجراءات</th>
                      </tr>
                    </thead>
                    <tbody>
                      {usersData?.users?.map((u: any) => (
                        <tr key={u.id} className="border-b border-border/10 hover:bg-muted/30 transition-colors">
                          <td className="p-3">
                            <div className="font-bold">{u.displayName}</div>
                            <div className="text-xs text-muted-foreground" dir="ltr">@{u.username}</div>
                          </td>
                          <td className="p-3 text-primary font-bold">{u.points ? u.points.toFixed(2) : "0.00"}</td>
                          <td className="p-3 font-mono">{((u.totalSeconds || 0) / 3600).toFixed(1)}</td>
                          <td className="p-3 text-sm text-muted-foreground">
                            {new Date(u.createdAt).toLocaleDateString("ar-JO")}
                          </td>
                          <td className="p-3 flex gap-2">
                            <Dialog open={adjustUserId === u.id} onOpenChange={(open) => !open && setAdjustUserId(null)}>
                              <DialogTrigger asChild>
                                <Button variant="outline" size="sm" onClick={() => {
                                  setAdjustUserId(u.id);
                                  setAdjustPoints((u.points || 0).toString());
                                  setAdjustSeconds((u.totalSeconds || 0).toString());
                                }}>
                                  <Edit className="w-4 h-4 ml-1.5" /> تعديل
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader><DialogTitle>تعديل بيانات {u.displayName}</DialogTitle></DialogHeader>
                                <form onSubmit={e => { e.preventDefault(); adjustUserMut.mutate({ id: adjustUserId!, points: parseFloat(adjustPoints || "0"), totalSeconds: parseInt(adjustSeconds || "0") }); }} className="space-y-4">
                                  <div className="space-y-2"><Label>النقاط</Label><Input type="number" step="0.01" value={adjustPoints} onChange={e => setAdjustPoints(e.target.value)} required /></div>
                                  <div className="space-y-2"><Label>إجمالي الثواني</Label><Input type="number" value={adjustSeconds} onChange={e => setAdjustSeconds(e.target.value)} required /></div>
                                  <DialogFooter><Button type="submit" disabled={adjustUserMut.isPending}>حفظ</Button></DialogFooter>
                                </form>
                              </DialogContent>
                            </Dialog>
                            <Button variant="destructive" size="sm" onClick={() => confirm("حذف المستخدم؟") && deleteUserMut.mutate(u.id)}>
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="inventory" className="mt-6">
          <Card className="border-primary/20 bg-card/50">
            <CardHeader>
              <CardTitle>حقائب جميع المستخدمين</CardTitle>
              <CardDescription>عرض العناصر التي اشتراها كل مستخدم</CardDescription>
            </CardHeader>
            <CardContent>
              {loadingInventory ? (
                <div className="flex justify-center p-8"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
              ) : inventoryData?.items?.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">لا يوجد عناصر في الحقائب بعد</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-right">
                    <thead>
                      <tr className="border-b border-border/50 text-muted-foreground text-sm">
                        <th className="p-3">المستخدم</th>
                        <th className="p-3">العنصر</th>
                        <th className="p-3">النوع</th>
                        <th className="p-3">القيمة</th>
                        <th className="p-3">تاريخ الاقتناء</th>
                      </tr>
                    </thead>
                    <tbody>
                      {inventoryData?.items?.map((item: any) => (
                        <tr key={item.id} className="border-b border-border/10 hover:bg-muted/30 transition-colors">
                          <td className="p-3">
                            <div className="font-bold">{item.displayName}</div>
                            <div className="text-xs text-muted-foreground" dir="ltr">@{item.username}</div>
                          </td>
                          <td className="p-3">
                            <span className="text-xl ml-2">{item.itemEmoji}</span>
                            <span className="font-medium">{item.itemName}</span>
                          </td>
                          <td className="p-3 text-xs">
                            <span className="bg-secondary px-2 py-0.5 rounded-full">
                              {item.effectType === "title" ? "لقب" : item.effectType === "gold_name" ? "اسم ذهبي" : item.effectType === "no_effect" ? "بدون تأثير" : "نقاط إضافية"}
                            </span>
                          </td>
                          <td className="p-3 text-sm text-muted-foreground">{item.effectValue}</td>
                          <td className="p-3 text-sm text-muted-foreground">
                            {new Date(item.acquiredAt).toLocaleDateString("ar-JO")}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="shop" className="mt-6 space-y-4">
          <div className="flex justify-end">
            <Dialog open={isAddShopOpen} onOpenChange={setIsAddShopOpen}>
              <DialogTrigger asChild>
                <Button className="gap-2"><Plus className="w-4 h-4" /> إضافة عنصر جديد</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>إضافة عنصر متجر</DialogTitle></DialogHeader>
                <form onSubmit={e => { e.preventDefault(); addShopItemMut.mutate({ name: newItemName, price: parseInt(newItemPrice), emoji: newItemEmoji, description: newItemDesc, effectType: newItemEffectType, effectValue: newItemEffectVal }); }} className="space-y-4">
                  <div className="space-y-2"><Label>الاسم</Label><Input value={newItemName} onChange={e => setNewItemName(e.target.value)} required /></div>
                  <div className="space-y-2"><Label>السعر (نقاط)</Label><Input type="number" value={newItemPrice} onChange={e => setNewItemPrice(e.target.value)} required /></div>
                  <div className="space-y-2"><Label>الرمز (Emoji)</Label><Input value={newItemEmoji} onChange={e => setNewItemEmoji(e.target.value)} /></div>
                  <div className="space-y-2"><Label>الوصف</Label><Input value={newItemDesc} onChange={e => setNewItemDesc(e.target.value)} /></div>
                  <div className="space-y-2">
                    <Label>نوع التأثير</Label>
                    <select className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm" value={newItemEffectType} onChange={e => setNewItemEffectType(e.target.value)}>
                      <option value="title">لقب</option>
                      <option value="gold_name">اسم ذهبي</option>
                      <option value="no_effect">بدون تأثير</option>
                      <option value="bonus_points">نقاط إضافية</option>
                    </select>
                  </div>
                  <div className="space-y-2"><Label>قيمة التأثير</Label><Input value={newItemEffectVal} onChange={e => setNewItemEffectVal(e.target.value)} placeholder="مثال: لقب العبقري أو 100" /></div>
                  <DialogFooter><Button type="submit" disabled={addShopItemMut.isPending}>إضافة العنصر</Button></DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          {loadingShop ? (
            <div className="flex justify-center p-8"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {shopData?.items?.map((item: any) => (
                <Card key={item.id} className="border-primary/20 bg-card/50 flex flex-col">
                  <CardHeader className="p-4 pb-2 text-center relative">
                    <Button variant="destructive" size="icon" className="absolute top-2 left-2 h-7 w-7 rounded-full opacity-60 hover:opacity-100" onClick={() => confirm("حذف هذا العنصر؟") && deleteShopItemMut.mutate(item.id)}>
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                    <div className="text-4xl mb-1">{item.emoji}</div>
                    <CardTitle className="text-base">{item.name}</CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 pt-0 text-center flex-grow">
                    <div className="text-muted-foreground text-xs mb-3 min-h-[2rem]">{item.description}</div>
                    <div className="bg-secondary/50 rounded p-2">
                      <div className="font-bold text-primary">{item.price} نقطة</div>
                      <div className="text-xs text-muted-foreground mt-0.5">
                        {item.effectType === "title" ? "لقب: " : item.effectType === "gold_name" ? "ذهبي" : item.effectType === "no_effect" ? "بدون تأثير" : "نقاط إضافية: "}
                        {item.effectType !== "no_effect" && item.effectType !== "gold_name" ? item.effectValue : ""}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="logs" className="mt-6">
          <Card className="border-primary/20 bg-card/50">
            <CardHeader>
              <CardTitle>سجل العمليات</CardTitle>
              <CardDescription>تتبع حركات الشراء والاستخدام</CardDescription>
            </CardHeader>
            <CardContent>
              {loadingLogs ? (
                <div className="flex justify-center p-8"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
              ) : (
                <div className="space-y-2">
                  {logsData?.logs?.length === 0 && <p className="text-center text-muted-foreground py-6">لا يوجد سجلات</p>}
                  {logsData?.logs?.map((log: any) => (
                    <div key={log.id} className="flex flex-col sm:flex-row justify-between sm:items-center p-3 rounded-lg border border-border/40 bg-background/40 gap-2">
                      <div className="flex items-center flex-wrap gap-2 text-sm">
                        <span className="font-bold text-primary">{log.displayName}</span>
                        <span className="text-muted-foreground">{log.actionType === "buy" ? "اشترى" : "استخدم"}</span>
                        <span className="bg-secondary px-2 py-0.5 rounded text-foreground font-medium">
                          {log.itemEmoji} {log.itemName}
                        </span>
                      </div>
                      <div className="text-xs text-muted-foreground shrink-0" dir="ltr">
                        {new Date(log.createdAt).toLocaleString("ar-JO")}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}