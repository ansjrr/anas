import { useEffect, useState, useRef, useCallback } from "react";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Play, Square, Clock, Zap, TrendingUp, BookOpen, ChevronRight, Bell, Megaphone, X } from "lucide-react";
import { useSyncUser } from "@workspace/api-client-react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
  DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell,
} from "recharts";

// ─── Constants ──────────────────────────────────────────────────────────────

const LEVEL_NAMES = [
  "مبتدئ", "متعلم", "مجتهد", "متقدم", "خبير",
  "متميز", "نجم", "أسطورة", "بطل", "أسطورة المذاكرة",
];

const SUBJECTS = ["رياضيات", "فيزياء", "كيمياء", "أحياء", "عربي", "إنجليزي", "تاريخ", "جغرافيا", "ثقافة إسلامية", "أخرى"];

const DAY_NAMES_SHORT = ["أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت"];

const CLOUD_ANNOUNCE_URL = "https://kvdb.io/StudentChatRoom_AnasJaarah_2026/announcements_list";

interface Announcement {
  id: string;
  text: string;
  time: string;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function getLevelInfo(totalSeconds: number) {
  const hours = totalSeconds / 3600;
  const level = Math.floor(hours / 6);
  const capped = Math.min(level, LEVEL_NAMES.length - 1);
  return {
    level: capped,
    name: LEVEL_NAMES[capped],
    progress: ((hours % 6) / 6) * 100,
    hoursToNext: 6 - (hours % 6),
  };
}

function fmt(s: number) {
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
}

function todayKey() {
  return new Date().toISOString().split("T")[0];
}

function dayKey(offset: number) {
  return new Date(Date.now() - offset * 86400000).toISOString().split("T")[0];
}

function hoursDecimal(sec: number) {
  return Math.round((sec / 3600) * 10) / 10;
}

// ─── Session store ────────────────────────────────────────────────────────────

interface StudySession {
  startedAt: number;
  endedAt: number;
  durationSeconds: number;
  date: string;
}

function loadSessions(userId: string): StudySession[] {
  try {
    return JSON.parse(localStorage.getItem(`wf_sessions_${userId}`) || "[]");
  } catch { return []; }
}

function saveSessions(userId: string, sessions: StudySession[]) {
  localStorage.setItem(`wf_sessions_${userId}`, JSON.stringify(sessions.slice(-50)));
}

// ─── Timer ring ──────────────────────────────────────────────────────────────

function TimerRing({ seconds, running, totalHours }: { seconds: number; running: boolean; totalHours: number }) {
  const R = 120;
  const C = 2 * Math.PI * R;
  const pct = (seconds % 3600) / 3600;
  const offset = C * (1 - pct);
  const hoursMark = Math.floor(seconds / 3600);

  return (
    <svg width="300" height="300" viewBox="0 0 300 300" className="block mx-auto drop-shadow-2xl">
      <defs>
        <radialGradient id="bgGrad" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="hsl(var(--card))" />
          <stop offset="100%" stopColor="hsl(var(--background))" />
        </radialGradient>
        <linearGradient id="arcGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="hsl(var(--primary))" />
          <stop offset="50%" stopColor="hsl(260 80% 70%)" />
          <stop offset="100%" stopColor="hsl(200 100% 70%)" />
        </linearGradient>
        <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="6" result="blur" />
          <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
        <filter id="softGlow" x="-10%" y="-10%" width="120%" height="120%">
          <feGaussianBlur stdDeviation="3" result="blur" />
          <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>

      {Array.from({ length: 60 }).map((_, i) => {
        const angle = (i / 60) * 2 * Math.PI - Math.PI / 2;
        const isMain = i % 5 === 0;
        const r1 = isMain ? 132 : 134;
        const r2 = 140;
        const filled = i / 60 <= pct;
        return (
          <line
            key={i}
            x1={150 + r1 * Math.cos(angle)} y1={150 + r1 * Math.sin(angle)}
            x2={150 + r2 * Math.cos(angle)} y2={150 + r2 * Math.sin(angle)}
            stroke={filled && running
              ? "hsl(var(--primary) / 0.8)"
              : isMain ? "hsl(var(--border) / 0.5)" : "hsl(var(--border) / 0.2)"}
            strokeWidth={isMain ? 2.5 : 1.5}
            strokeLinecap="round"
          />
        );
      })}

      <circle cx="150" cy="150" r={R} fill="none"
        stroke="hsl(var(--border) / 0.15)" strokeWidth="12" />

      <circle cx="150" cy="150" r={R} fill="none"
        stroke="url(#arcGrad)" strokeWidth="12"
        strokeLinecap="round"
        strokeDasharray={C} strokeDashoffset={offset}
        transform="rotate(-90 150 150)"
        style={{ transition: running ? "stroke-dashoffset 0.8s linear" : "none" }}
        filter={running ? "url(#glow)" : undefined}
      />

      <circle cx="150" cy="150" r="108" fill="url(#bgGrad)" />
      <circle cx="150" cy="150" r="108" fill="none"
        stroke="hsl(var(--border) / 0.08)" strokeWidth="1" />

      {hoursMark > 0 && (
        <g>
          <rect x="120" y="90" width="60" height="20" rx="10"
            fill="hsl(var(--primary) / 0.2)" />
          <text x="150" y="104" textAnchor="middle"
            fontSize="11" fill="hsl(var(--primary))" fontWeight="600">
            {hoursMark} {hoursMark === 1 ? "ساعة" : "ساعات"}
          </text>
        </g>
      )}

      <text x="150" y="158" textAnchor="middle" dominantBaseline="middle"
        fontSize="42" fontWeight="700" fontFamily="monospace"
        fill="hsl(var(--foreground))" letterSpacing="3"
        filter={running ? "url(#softGlow)" : undefined}>
        {fmt(seconds)}
      </text>

      {running ? (
        <text x="150" y="186" textAnchor="middle"
          fontSize="12" fill="hsl(var(--primary))" fontWeight="500">
          ⏱ جارٍ المذاكرة...
        </text>
      ) : (
        <text x="150" y="186" textAnchor="middle"
          fontSize="12" fill="hsl(var(--muted-foreground))" fontWeight="500">
          جلسة جديدة
        </text>
      )}

      <text x="150" y="204" textAnchor="middle"
        fontSize="10" fill="hsl(var(--muted-foreground) / 0.7)">
        {totalHours.toFixed(1)} ساعة إجمالي
      </text>

      {running && (
        <circle cx="150" cy="44" r="5" fill="hsl(var(--primary))" filter="url(#glow)">
          <animate attributeName="opacity" values="1;0.2;1" dur="1.2s" repeatCount="indefinite" />
        </circle>
      )}
    </svg>
  );
}

// ─── Weekly chart ─────────────────────────────────────────────────────────────

function WeeklyChart({ history }: { history: Record<string, number> }) {
  const data = Array.from({ length: 7 }, (_, i) => {
    const k = dayKey(6 - i);
    const dayIndex = new Date(k).getDay();
    return {
      day: DAY_NAMES_SHORT[dayIndex],
      hours: hoursDecimal(history[k] || 0),
      isToday: k === todayKey(),
    };
  });

  const max = Math.max(...data.map(d => d.hours), 1);

  return (
    <div className="rounded-2xl border border-border/30 bg-card/80 backdrop-blur px-4 pt-4 pb-3">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-primary" />
          <span className="text-sm font-semibold">معدل الاستهلاك الدراسي الأسبوعي</span>
        </div>
        <span className="text-xs text-muted-foreground">
          {data.reduce((s, d) => s + d.hours, 0).toFixed(1)} ساعة
        </span>
      </div>
      <ResponsiveContainer width="100%" height={120}>
        <BarChart data={data} barCategoryGap="20%" margin={{ top: 4, right: 4, left: -28, bottom: 0 }}>
          <XAxis dataKey="day" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
            axisLine={false} tickLine={false} />
          <YAxis tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
            axisLine={false} tickLine={false} domain={[0, Math.ceil(max + 0.5)]} />
          <Tooltip
            formatter={(v: number) => [`${v} ساعة`, "الدراسة"]}
            contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }}
            cursor={{ fill: "hsl(var(--primary) / 0.05)" }}
          />
          <Bar dataKey="hours" radius={[6, 6, 0, 0]}>
            {data.map((entry, i) => (
              <Cell key={i} fill={entry.isToday
                ? "hsl(var(--primary))"
                : "hsl(var(--primary) / 0.35)"}
              />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

// ─── Sessions mini list ───────────────────────────────────────────────────────

function SessionsList({ sessions }: { sessions: StudySession[] }) {
  const todaySessions = sessions.filter(s => s.date === todayKey());
  if (todaySessions.length === 0) return null;

  return (
    <div className="rounded-2xl border border-border/30 bg-card/80 px-4 py-3">
      <div className="flex items-center gap-2 mb-2">
        <Clock className="w-4 h-4 text-primary" />
        <span className="text-sm font-semibold">جلسات اليوم</span>
        <span className="text-xs bg-primary/15 text-primary px-2 py-0.5 rounded-full mr-auto">
          {todaySessions.length} جلسة
        </span>
      </div>
      <div className="space-y-1.5">
        {todaySessions.slice(-5).reverse().map((s, i) => (
          <div key={i} className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground" dir="ltr">
              {new Date(s.startedAt).toLocaleTimeString("ar-JO", { hour: "2-digit", minute: "2-digit" })}
              {" – "}
              {new Date(s.endedAt).toLocaleTimeString("ar-JO", { hour: "2-digit", minute: "2-digit" })}
            </span>
            <span className="font-mono font-medium text-primary">
              {fmt(s.durationSeconds)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────

export default function Home() {
  const [, setLocation] = useLocation();
  const { user, updateUser } = useAuth();

  const [isRunning, setIsRunning] = useState(false);
  const [sessionSeconds, setSessionSeconds] = useState(0);
  const [sessionStartTime, setSessionStartTime] = useState<number | null>(null);
  const [sessions, setSessions] = useState<StudySession[]>([]);

  const [pendingHours, setPendingHours] = useState<number[]>([]);
  const [achievementSubject, setAchievementSubject] = useState("");
  const [achievementText, setAchievementText] = useState("");

  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [showAnnPanel, setShowAnnPanel] = useState(false);
  const [lastViewedCount, setLastViewedCount] = useState(0);

  const showAchievement = pendingHours.length > 0;
  const syncMutation = useSyncUser();
  const sessionSecondsRef = useRef(0);
  const isRunningRef = useRef(false);
  const lastSyncRef = useRef(0);
  const sessionStartRef = useRef<number | null>(null);

  sessionSecondsRef.current = sessionSeconds;
  isRunningRef.current = isRunning;
  sessionStartRef.current = sessionStartTime;

  useEffect(() => {
    if (!user) setLocation("/");
  }, [user, setLocation]);

  useEffect(() => {
    const fetchAnnounceList = async () => {
      try {
        const res = await fetch(CLOUD_ANNOUNCE_URL);
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data)) setAnnouncements(data);
        }
      } catch (e) { console.error(e); }
    };
    fetchAnnounceList();
    const interval = setInterval(fetchAnnounceList, 3500);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!user) return;

    setSessions(loadSessions(user.id as string));

    const raw = localStorage.getItem(`wf_timer_${user.id}`);
    if (!raw) return;

    try {
      const { startedAt, baseSeconds, running, syncedSeconds, timerDate } = JSON.parse(raw);
      const today = todayKey();
      if (timerDate && timerDate !== today) {
        localStorage.setItem(`wf_timer_${user.id}`, JSON.stringify({
          startedAt: null, baseSeconds: 0, running: false,
          syncedSeconds: 0, timerDate: today,
        }));
        setSessionSeconds(0);
        lastSyncRef.current = 0;
        return;
      }

      lastSyncRef.current = syncedSeconds || 0;

      if (running && startedAt) {
        const elapsed = Math.floor((Date.now() - startedAt) / 1000);
        const restored = (baseSeconds || 0) + elapsed;
        setSessionSeconds(restored);
        setIsRunning(true);
        setSessionStartTime(startedAt);

        const lastDocHour = Math.floor((baseSeconds || 0) / 3600);
        const currentHour = Math.floor(restored / 3600);
        if (currentHour > lastDocHour) {
          const missed = Array.from(
            { length: currentHour - lastDocHour },
            (_, i) => lastDocHour + i + 1,
          );
          setPendingHours(missed);
        }
      } else {
        setSessionSeconds(baseSeconds || 0);
      }
    } catch { /* ignore */ }
  }, [user]);

  useEffect(() => {
    if (!user) return;
    const checkMidnight = () => {
      const raw = localStorage.getItem(`wf_timer_${user.id}`);
      if (!raw) return;
      try {
        const saved = JSON.parse(raw);
        if (saved.timerDate && saved.timerDate !== todayKey()) {
          setIsRunning(false);
          setSessionSeconds(0);
          lastSyncRef.current = 0;
          localStorage.setItem(`wf_timer_${user.id}`, JSON.stringify({
            startedAt: null, baseSeconds: 0, running: false,
            syncedSeconds: 0, timerDate: todayKey(),
          }));
        }
      } catch { /* ignore */ }
    };
    const interval = setInterval(checkMidnight, 60000);
    return () => clearInterval(interval);
  }, [user]);

  useEffect(() => {
    if (!isRunning) return;
    const t = setInterval(() => {
      setSessionSeconds(s => {
        const next = s + 1;
        if (next % 30 === 0 && user) {
          const raw = localStorage.getItem(`wf_timer_${user.id}`);
          if (raw) {
            const prev = JSON.parse(raw);
            localStorage.setItem(`wf_timer_${user.id}`, JSON.stringify({
              ...prev,
              startedAt: Date.now(),
              baseSeconds: next,
              timerDate: todayKey(),
            }));
          }
        }
        const currentHour = Math.floor(next / 3600);
        const prevHour = Math.floor((next - 1) / 3600);
        if (currentHour > prevHour && currentHour > 0) {
          setPendingHours(q => [...q, currentHour]);
        }
        return next;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [isRunning, user]);

  const doSync = useCallback((secs: number) => {
    if (!user) return;
    const secondsToSync = secs - lastSyncRef.current;
    if (secondsToSync <= 0) return;

    const history: Record<string, number> = { ...((user.history as Record<string, number>) || {}) };
    const key = todayKey();
    history[key] = (history[key] || 0) + secondsToSync;

    const totalSeconds = (user.totalSeconds || 0) + secondsToSync;

    const earnedPoints = Math.floor(totalSeconds / 3600) - Math.floor((user.totalSeconds || 0) / 3600);
    const points = (user.points || 0) + Math.max(0, earnedPoints);

    syncMutation.mutate(
      { userId: user.id as string, data: { totalSeconds, points, history } },
      {
        onSuccess: (data) => {
          if (data.success) {
            updateUser({ totalSeconds: data.totalSeconds, points: data.points, history });
            lastSyncRef.current = secs;
            if (user) {
              const raw = localStorage.getItem(`wf_timer_${user.id}`);
              if (raw) {
                const prev = JSON.parse(raw);
                localStorage.setItem(`wf_timer_${user.id}`, JSON.stringify({
                  ...prev, syncedSeconds: secs,
                }));
              }
            }
          }
        },
      }
    );
  }, [user, syncMutation, updateUser]);

  useEffect(() => {
    if (!isRunning) return;
    const t = setInterval(() => doSync(sessionSecondsRef.current), 60000);
    return () => clearInterval(t);
  }, [isRunning, doSync]);

  useEffect(() => {
    const onHide = () => {
      if (isRunningRef.current) doSync(sessionSecondsRef.current);
    };
    document.addEventListener("visibilitychange", onHide);
    window.addEventListener("beforeunload", onHide);
    return () => {
      document.removeEventListener("visibilitychange", onHide);
      window.removeEventListener("beforeunload", onHide);
    };
  }, [doSync]);

  const startTimer = () => {
    if (!user) return;
    const now = Date.now();
    setSessionSeconds(0);
    lastSyncRef.current = 0;
    setSessionStartTime(now);
    localStorage.setItem(`wf_timer_${user.id}`, JSON.stringify({
      startedAt: now,
      baseSeconds: 0,
      running: true,
      syncedSeconds: 0,
      timerDate: todayKey(),
    }));
    setIsRunning(true);
  };

  const stopTimer = () => {
    if (!user) return;
    const now = Date.now();
    const duration = sessionSecondsRef.current;

    if (duration > 5 && sessionStartRef.current) {
      const newSession: StudySession = {
        startedAt: sessionStartRef.current,
        endedAt: now,
        durationSeconds: duration,
        date: todayKey(),
      };
      setSessions(prev => {
        const updated = [...prev, newSession];
        saveSessions(user.id as string, updated);
        return updated;
      });
    }

    localStorage.setItem(`wf_timer_${user.id}`, JSON.stringify({
      startedAt: null, baseSeconds: 0,
      running: false, syncedSeconds: 0,
      timerDate: todayKey(),
    }));

    setIsRunning(false);
    setSessionStartTime(null);
    doSync(duration);
    setSessionSeconds(0);
    lastSyncRef.current = 0;
  };

  const toggleTimer = () => (isRunning ? stopTimer() : startTimer());

  const submitAchievement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    const hourNum = pendingHours[0];
    await fetch(`/api/workflow/users/${user.id}/achievements`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        subject: achievementSubject,
        achievement: achievementText,
        hoursStudied: 1,
      }),
    });
    setPendingHours(q => q.slice(1));
    setAchievementSubject("");
    setAchievementText("");
    void hourNum;
  };

  const skipAchievement = () => {
    setPendingHours(q => q.slice(1));
  };

  const handleOpenAnnouncements = () => {
    setShowAnnPanel(!showAnnPanel);
    setLastViewedCount(announcements.length);
  };

  const history: Record<string, number> = (user?.history as Record<string, number>) || {};
  const todaySec = history[todayKey()] || 0;
  const levelInfo = getLevelInfo(user?.totalSeconds || 0);
  const totalHours = (user?.totalSeconds || 0) / 3600;

  const unreadCount = Math.max(0, announcements.length - lastViewedCount);

  if (!user) return null;

  return (
    <div className="max-w-lg mx-auto space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-8 text-right relative" dir="rtl">

      {/* 🔔 شريط الأدوات العلوية المدمج فيه جرس الإشعارات */}
      <div className="flex items-center justify-between bg-card border border-border/30 rounded-2xl p-3 shadow-sm">
        <span className="text-sm font-bold text-foreground">لوحة تحكم الطالب</span>
        <div className="relative">
          <Button 
            onClick={handleOpenAnnouncements}
            variant="ghost" 
            size="icon" 
            className="rounded-xl relative text-[#c9a84c] border border-[#c9a84c]/20 bg-[#c9a84c]/5 hover:bg-[#c9a84c]/10"
          >
            <Bell className="w-5 h-5" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -left-1 bg-red-500 text-white font-bold font-mono rounded-full text-[9px] w-4 h-4 flex items-center justify-center animate-bounce">
                {unreadCount}
              </span>
            )}
          </Button>

          {/* لوحة عرض الإشعارات المنسدلة الاحترافية */}
          {showAnnPanel && (
            <div className="absolute left-0 top-12 w-72 bg-card border border-border/60 shadow-xl rounded-2xl p-3 z-50 space-y-2 animate-in zoom-in-95 duration-200">
              <div className="flex items-center justify-between border-b border-border/40 pb-2">
                <div className="flex items-center gap-1 text-xs font-bold text-foreground">
                  <Megaphone className="w-3.5 h-3.5 text-[#c9a84c]" />
                  <span>مركز التعميمات والإشعارات</span>
                </div>
                <button onClick={() => setShowAnnPanel(false)} className="text-muted-foreground hover:text-foreground"><X className="w-3.5 h-3.5" /></button>
              </div>
              <div className="max-h-60 overflow-y-auto space-y-2 custom-scrollbar">
                {announcements.length === 0 ? (
                  <p className="text-[11px] text-muted-foreground text-center py-4">صندوق الإشعارات فارغ حالياً.</p>
                ) : (
                  announcements.map((ann) => (
                    <div key={ann.id} className="bg-muted/40 border border-border/20 rounded-xl p-2.5 text-right space-y-1">
                      <p className="text-xs text-foreground font-medium leading-relaxed break-words">{ann.text}</p>
                      <span className="text-[9px] text-muted-foreground/50 block font-mono text-left">{ann.time}</span>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* لوحة التايمر والمؤقت */}
      <div className={`relative rounded-3xl border-2 overflow-hidden transition-all duration-700 ${
        isRunning
          ? "border-primary/50 bg-gradient-to-b from-card to-primary/5 shadow-[0_0_60px_hsl(var(--primary)/0.12)]"
          : "border-border/30 bg-card"
      }`}>
        {isRunning && (
          <div className="absolute inset-0 bg-gradient-radial from-primary/5 to-transparent pointer-events-none" />
        )}

        <div className="pt-8 pb-4">
          <TimerRing seconds={sessionSeconds} running={isRunning} totalHours={totalHours} />
        </div>

        <div className="flex items-center justify-center gap-6 pb-3 px-6">
          <div className="text-center">
            <div className="text-xs text-muted-foreground">اليوم</div>
            <div className="font-bold text-sm text-primary">{hoursDecimal(todaySec + (isRunning ? sessionSeconds : 0)).toFixed(1)}س</div>
          </div>
          <div className="h-8 w-px bg-border/40" />
          <div className="text-center">
            <div className="text-xs text-muted-foreground">هذا الأسبوع</div>
            <div className="font-bold text-sm">
              {hoursDecimal(
                Array.from({ length: 7 }, (_, i) => history[dayKey(i)] || 0).reduce((a, b) => a + b, 0)
              ).toFixed(1)}س
            </div>
          </div>
          <div className="h-8 w-px bg-border/40" />
          <div className="text-center">
            <div className="text-xs text-muted-foreground">النقاط</div>
            <div className="font-bold text-sm text-yellow-400">{Math.round(user.points || 0)}</div>
          </div>
        </div>

        <div className="px-6 pb-6">
          <Button
            size="lg"
            className={`w-full h-14 text-base font-bold gap-3 rounded-2xl transition-all duration-300 ${
              isRunning
                ? "bg-rose-600 hover:bg-rose-700 text-white shadow-[0_4px_24px_rgba(225,29,72,0.35)]"
                : "shadow-[0_4px_24px_hsl(var(--primary)/0.3)] hover:shadow-[0_4px_32px_hsl(var(--primary)/0.45)]"
            }`}
            onClick={toggleTimer}
            data-testid="button-toggle-timer"
          >
            {isRunning ? (
              <><Square className="w-5 h-5 fill-current" /> إيقاف الجلسة</>
            ) : (
              <><Play className="w-5 h-5 fill-current" /> ابدأ المذاكرة</>
            )}
          </Button>
        </div>
      </div>

      <div className="rounded-2xl border border-border/30 bg-card px-4 py-3">
        <div className="flex justify-between items-center mb-2">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-yellow-500" />
            <span className="font-bold text-sm text-primary">{levelInfo.name}</span>
            <span className="text-xs bg-primary/15 text-primary px-2 py-0.5 rounded-full font-mono">
              {levelInfo.level}
            </span>
          </div>
          <span className="text-xs text-muted-foreground">
            {levelInfo.hoursToNext.toFixed(1)}س للمستوى التالي
          </span>
        </div>
        <div className="h-2 rounded-full bg-secondary overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-primary via-purple-400 to-blue-400 transition-all duration-1000"
            style={{ width: `${levelInfo.progress}%` }}
          />
        </div>
      </div>

      <WeeklyChart history={{
        ...history,
        [todayKey()]: (history[todayKey()] || 0) + (isRunning ? sessionSeconds : 0),
      }} />

      <SessionsList sessions={sessions} />

      {/* 💬 زر دخول الشات المذهب */}
      <div className="pt-1">
        <button
          onClick={() => setLocation("/chat")}
          type="button"
          className="w-full h-12 bg-gradient-to-r from-[#c9a84c]/25 to-transparent hover:from-[#c9a84c]/35 border border-[#c9a84c]/40 hover:border-[#c9a84c] text-[#c9a84c] font-bold rounded-2xl shadow-md transition-all duration-300 flex items-center justify-center gap-3 group text-sm"
        >
          <span className="text-lg group-hover:scale-125 transition-transform duration-300">💬</span>
          <span>دخول مجلس الشات العام للطلاب لايف</span>
          <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse mr-1"></span>
        </button>
      </div>

      <div className="rounded-2xl border border-border/20 bg-card/60 px-5 py-3 flex justify-between items-center">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <BookOpen className="w-4 h-4" />
          إجمالي المذاكرة
        </div>
        <div className="flex items-center gap-1 text-primary font-bold">
          <span className="text-xl font-mono">{totalHours.toFixed(1)}</span>
          <span className="text-sm font-normal text-muted-foreground">ساعة</span>
          <ChevronRight className="w-4 h-4 text-muted-foreground/40" />
        </div>
      </div>

      <Dialog open={showAchievement} onOpenChange={(o) => { if (!o) skipAchievement(); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>🎯 أتممت الساعة {pendingHours[0]}</DialogTitle>
            <DialogDescription>
              وثّق ما أنجزته في هذه الساعة.
              {pendingHours.length > 1 && (
                <span className="text-primary font-medium mr-1">
                  ({pendingHours.length - 1} ساعة أخرى تنتظر التوثيق)
                </span>
              )}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={submitAchievement} className="space-y-4">
            <div className="space-y-2">
              <Label>المادة</Label>
              <select
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                value={achievementSubject}
                onChange={e => setAchievementSubject(e.target.value)}
                required
              >
                <option value="">اختر المادة...</option>
                {SUBJECTS.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div className="space-y-2">
              <Label>ماذا أنجزت في هذه الساعة؟</Label>
              <Textarea
                placeholder="مثال: حل أسئلة الوحدة الأولى، قراءة الفصل الثاني..."
                value={achievementText}
                onChange={e => setAchievementText(e.target.value)}
                required
              />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={skipAchievement}>تخطي</Button>
              <Button type="submit">حفظ الإنجاز</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}